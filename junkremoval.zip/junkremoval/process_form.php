<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "junkremoval";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    echo "Database connection failed!";
    exit;
}

// Get POST data safely
$name = $_POST['form_fields']['name'] ?? '';
$phone = $_POST['form_fields']['phone'] ?? '';
$date = $_POST['form_fields']['field_a789202'] ?? '';
$time = $_POST['form_fields']['field_f503a3e'] ?? '';
$service = $_POST['form_fields']['field_2c7e43b'] ?? '';
$message = $_POST['form_fields']['message'] ?? '';

// Insert without validation (as requested)
$sql = "INSERT INTO bookings (name, phone, date, time, service, message) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssss", $name, $phone, $date, $time, $service, $message);

if ($stmt->execute()) {
    echo "✅ Booking confirmed!";
} else {
    echo "❌ Error: " . $stmt->error;
 }

$stmt->close();
$conn->close();
?>
