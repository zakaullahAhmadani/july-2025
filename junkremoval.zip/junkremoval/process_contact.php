<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "junkremoval";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("<p style='color:red;'>Connection failed: " . $conn->connect_error . "</p>");
}

$name = isset($_POST['name']) ? $conn->real_escape_string(trim($_POST['name'])) : '';
$phone = isset($_POST['phone']) ? $conn->real_escape_string(trim($_POST['phone'])) : '';
$email = isset($_POST['email']) ? $conn->real_escape_string(trim($_POST['email'])) : '';
$subject = isset($_POST['subject']) ? $conn->real_escape_string(trim($_POST['subject'])) : '';
$message = isset($_POST['message']) ? $conn->real_escape_string(trim($_POST['message'])) : '';

$sql = "INSERT INTO contact_messages (name, phone, email, subject, message) 
        VALUES ('$name', '$phone', '$email', '$subject', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color:green;'>Thank you! Your message has been sent.</p>";
} else {
    echo "<p style='color:red;'>Error: " . $conn->error . "</p>";
}

$conn->close();
?>
