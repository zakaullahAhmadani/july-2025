<?php
// Enable error reporting for debugging (remove in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// DB connection info
$host = "localhost";
$user = "root";
$password = "";
$dbname = "junkremoval";

// Connect to database
$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}

// Check if data exists
if (isset($_POST['form_fields']['email'])) {
    $email = trim($_POST['form_fields']['email']);

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "❌ Invalid email address.";
        exit;
    }

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO subscribers (email) VALUES (?)");
    if ($stmt === false) {
        die("❌ Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        echo "✅ Thanks for signing up!";
    } else {
        echo "❌ Error saving your email.";
    }

    $stmt->close();
} else {
    echo "❌ Email is missing.";
}

$conn->close();
?>
