<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
        <link rel="icon" type="image/png" href="images/scrap-buyers-riyadh-Logo-Final-1_1.webp"> 
       <title>
      مشتري الخردة في الرياض
</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- ✅ Bootstrap RTL CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">

    <!-- ✅ Font Awesome (optional) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> 
    <style>
        .navbar-nav .nav-link {
            font-size: 1.1rem;
        }

        .lang-select {
            min-width: 150px;
        }

        .top-bar {
            background-color: #ffffff;
            border-bottom: 1px solid #dee2e6;
        }

        .main-navbar {
            background-color: #0099ff;
        }

        .main-navbar .nav-link {
            color: white !important;
        }

        .main-navbar .nav-link.active,
        .main-navbar .nav-link:hover {
            background-color: white !important;
            color: #0099ff !important;
            border-radius: 5px;
            padding: 6px 12px;
        }
        .logo-circle {
    height: 70px;
    width: 70px;
    object-fit: cover;
    border-radius: 50%; /* Makes the logo circular */
    border: 1px solid #0099ff; /* Optional: colored border */
}

.top-bar .container {
    align-items: flex-end !important; /* Bottom align */
    padding-left: 0 !important;       /* Remove left padding if needed */
}

.top-bar {
    padding-bottom: -20px;                /* Tight fit with bottom */
}
html, body {
    height: 100vh;
    width: 100vw;
    overflow-x: hidden;   /* Disable horizontal scroll */
    overflow-y: auto;     /* Enable vertical scroll */
    margin: 0;
    padding: 0;
    white-space: normal;
}

section {
    display: block;
    width: 100%;
    height: auto;         /* Allow section height to adjust based on content */
    padding: 20px;
    box-sizing: border-box;
}
 .testimonial-card {
            background: white;
            border: 1px solid #eee;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
            text-align: center;
            direction: rtl;
            height: 100%;
        }
        .testimonial-card img {
            border-radius: 10px;
            width: 100%;
            height: 300px;
            object-fit: cover;
        }
        .testimonial-card h4 {
            font-weight: bold;
            margin-top: 15px;
            font-size: 24px;
        }
        .stars {
            color: #000;
            font-size: 26px;
            margin-bottom: 10px;
        }
        .testimonial-card p {
            font-size: 18px;
            line-height: 1.8;
        }

    </style>
</head>
<body>

    <!-- 🟦 Top Bar -->
   <div class="top-bar py-2">
    <div class="container d-flex justify-content-between align-items-center" style="direction: ltr;">
        
        <!-- Left: Logo -->
   <div class="d-flex align-items-end gap-3">
    <a href="<?php echo e(url('/')); ?>" class="footer_link d-block mb-3">
                  <img src="images/scrap-buyers-riyadh-Logo-Final-1.png"
     alt="مشتري خردة الرياض"
     class="img-fluid"
     style="max-width: 150px; margin-bottom: 5px; margin-left: 4px;">
                </a>
</div>
        <!-- Right: Contact Info + Language Selector -->
        <div class="d-flex align-items-center gap-3">
            <div class="text-end">
                <div class="fw-bold">  <a href="tel:+966543282605" class="text-decoration-none text-dark">
            +966 54 328 2605
        </a></div>
                <div><a href="mailto:info@scrapbuyersriyadh.com">info@scrapbuyersriyadh.com</a></div>
            </div>
            <div id="google_translate_element" class="lang-select"></div>
        </div>
    </div>
</div>
    <!-- 🟦 Main Navbar -->
    <nav class="navbar navbar-expand-lg main-navbar">
        <div class="container justify-content-end">
            <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-end" id="mainNav">
                <ul class="navbar-nav mb-2 mb-lg-0 d-flex flex-row-reverse gap-3">
                    <li class="nav-item"><a class="nav-link active" href="">الصفحة الرئيسية</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('contact')); ?>">خدمات</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">معلومات عنا</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">اتصل بنا</a></li>
                   <!-- <li class="nav-item ms-auto">
    <a class="nav-link fw-bold" href="#" style="background-color: white; color:rgb(140, 188, 220); border-radius: 5px; padding: 6px 12px;">
        المواعيد
    </a>
</li> -->
                </ul>
            </div>
        </div>
    </nav>
    <br>
    
<br><br>

 <div class="container py-5" dir="ltr">
    <h2 class="mb-4 text-center">اتصل</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('contact.submit')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="name" class="form-label visually-hidden">Name</label>
            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   id="name" name="name" placeholder="Name" value="<?php echo e(old('name')); ?>" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label visually-hidden">Email</label>
            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   id="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label for="comment" class="form-label visually-hidden">Comment</label>
            <textarea class="form-control <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      id="comment" name="comment" rows="5" placeholder="Comment" required><?php echo e(old('comment')); ?></textarea>
            <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" value="check" id="saveInfo">
            <label class="form-check-label" for="saveInfo">
                Save my name, email, and website in this browser.
            </label>
        </div>

        <button type="submit" class="btn btn-primary">Send</button>
    </form>

    <div class="mt-5 text-center">
        <img src="<?php echo e(asset('images/images_6.jpg')); ?>" class="img-fluid" alt="Contact Image" width="259" height="194">
    </div>

<!-- Google Map Section -->
<section class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <iframe
                width="100%"
                height="450"
                style="border:0;"
                loading="lazy"
                allowfullscreen
                title="Google Map"
                src="https://maps.google.com/maps?z=14&t=m&q=Riyadh&ie=UTF8&output=embed"
            ></iframe>
        </div>
    </div>
</section>

<br>


<br><br>
<!-- Contact Section -->
<section class="contact-section bg-primary text-white py-4">
    <div class="container">
        <div class="row align-items-center">
            <!-- Email -->
           <div class="col-md-4 text-center text-md-start">
    <div class="d-flex align-items-center justify-content-center h-100">
        <i class="fas fa-envelope fa-2x mb-2"></i>
    </div>
    <p><a href="mailto:info@scrapbuyersriyadh.com" class="text-white">info@scrapbuyersriyadh.com</a></p>
</div>

   
    <div class="col-md-4 d-flex flex-column align-items-center" dir="ltr">
    <i class="fas fa-phone fa-2x mb-2"></i>
    <div class="fw-bold">
        <a href="tel:+966543282605" class="text-decoration-none text-white">
            +966 54 328 2605
        </a>
    </div>
</div>
            <!-- Location -->
            <div class="col-md-4 text-center text-md-end">
                <i class="fas fa-map-marker-alt fa-2x mb-2"></i>
                <p>جدة، الرياض</p>
            </div>
        </div>
    </div>
</section>


<br>

<footer id="Banner-footer" class="index-footer footer bg-dark text-white py-5" dir="ltr">
    <div class="container">
        <div class="row">
            <!-- Block 1: Logo & Description -->
            <div class="col-md-4 mb-4">
                <a href="<?php echo e(url('/')); ?>" class="footer_link d-block mb-3">
                    <img src="images/scrap-buyers-riyadh-Logo-Final-1.png"
                         alt="مشتري خردة الرياض"
                         class="img-fluid" style="max-width: 200px;">
                </a>
                <p class="mt-3 text-white">
                    نقوم بشراء جميع أنواع الخردة المعدنية أسلاك الحديد الأسلاك النحاسية الألومنيوم البطاريات المستخدمة خردة تكييف الهواء نحن نشتري جميع أنواع الخردة المعدنية في المملكة العربية السعودية الرياض والمعادن والمواد غير الحديدية.
                </p>

                <!-- Social Icons -->
                <div class="social_icons mt-4">
                    <p>Follow Us:</p>
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item me-2">
                            <a href="#" class="text-white text-decoration-none">
                                <i class="fab fa-twitter fs-5"></i>
                            </a>
                        </li>
                        <li class="list-inline-item me-2">
                            <a href="#" class="text-white text-decoration-none">
                                <i class="fab fa-facebook fs-5"></i>
                            </a>
                        </li>
                        <li class="list-inline-item me-2">
                            <a href="#" class="text-white text-decoration-none">
                                <i class="fab fa-instagram fs-5"></i>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="#" class="text-white text-decoration-none">
                                <i class="fab fa-youtube fs-5"></i>
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- WhatsApp Icon (Removed) -->
                <!--
                <div class="mt-4">
                    <a href="tel:+966543282605" class="d-inline-block">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50" fill="none">
                            <circle cx="25" cy="25" r="25" fill="#25D366"/>
                            <path d="M25 2.5C11.293 2.5 2.5 11.293 2.5 25C2.5 38.707 11.293 47.5 25 47.5C38.707 47.5 47.5 38.707 47.5 25C47.5 11.293 38.707 2.5 25 2.5Z" fill="#fff"/>
                            <path d="M25 4.1667C13.75 4.1667 4.1667 13.75 4.1667 25C4.1667 36.25 13.75 45.8333 25 45.8333C36.25 45.8333 45.8333 36.25 45.8333 25C45.8333 13.75 36.25 4.1667 25 4.1667Z" fill="#fff"/>
                            <path d="M25 8.33333C18.8333 8.33333 13.3333 13.8333 13.3333 20C13.3333 26.1667 18.8333 31.6667 25 31.6667C31.1667 31.6667 36.6667 26.1667 36.6667 20C36.6667 13.8333 31.1667 8.33333 25 8.33333Z" fill="#fff"/>
                        </svg>
                    </a>
                </div>
                -->

            </div>

            <!-- Block 2: Services Menu -->
            <div class="col-md-4 mb-4">
                <ul class="footer_menu list-unstyled">
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('services')); ?>" class="text-white">خدمات</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('buy-iron-scrap')); ?>" class="text-white">شراء سكراب حديد</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('riyadh')); ?>" class="text-white">الرياض</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('buy-scrap')); ?>" class="text-white">نشتري السكراب</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('buy-metal-scrap')); ?>" class="text-white">شراء السكراب حديد</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('scrap-in-riyadh')); ?>" class="text-white">خردة بالرياض</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('buy-iron-scrap')); ?>" class="text-white">شراء حديد سكراب</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('riyadh')); ?>" class="text-white">الرياض</a></li>
                </ul>
            </div>

            <!-- Block 3: Main Links -->
            <div class="col-md-4 mb-4">
                <ul class="footer_menu list-unstyled">
                    <li><span class="text-primary">•</span> <a href="<?php echo e(url('/')); ?>" class="text-white">الصفحة الرئيسية</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('contact')); ?>" class="text-white">اتصل بنا</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('about')); ?>" class="text-white">معلومات عنا</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('services')); ?>" class="text-white">خدمات</a></li>
                </ul>

                <!-- Images Grid -->
                <div class="row g-2 mt-4">
                    <?php $__currentLoopData = [
                        'https://via.placeholder.com/150',    
                        'https://via.placeholder.com/150',    
                        'https://via.placeholder.com/150',    
                        'https://via.placeholder.com/150',    
                        'https://via.placeholder.com/150',    
                        'https://via.placeholder.com/150'    
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-4">
                            <img src="<?php echo e($img); ?>" alt="" class="img-fluid rounded">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
</div>
</div>
</div>
  </footer>

        <!-- Bottom Footer -->
       <div class=" bg-primary ">
        <!-- Left Column: Copyright and Social Icons -->
       <div class="row justify-content-center">
  <div class="col-md-6 text-center">
    <small class="copyright__content text-white">
      &copy; Copyright © 2025 Design by Innovative Technologies
    </small>
  </div>
</div>
</div>



    <!-- ✅ Google Translate Script -->
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ar',
                layout: google.translate.TranslateElement.InlineLayout.SIMPLE
            }, 'google_translate_element');
        }
    </script>
    <script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    <!-- ✅ Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

<?php /**PATH E:\scrapbuyersriyadh\scrapbuyersriyadh\resources\views/pages/contact.blade.php ENDPATH**/ ?>