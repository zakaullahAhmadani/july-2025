<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
        <link rel="icon" type="image/png" href="images/scrap-buyers-riyadh-Logo-Final-1_1.webp"> 
       <title>
      مشتري الخردة في الرياض
</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- ✅ Bootstrap RTL CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">

    <!-- ✅ Font Awesome (optional) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> 
    <style>
        .navbar-nav .nav-link {
            font-size: 1.1rem;
        }

        .lang-select {
            min-width: 150px;
        }

        .top-bar {
            background-color: #ffffff;
            border-bottom: 1px solid #dee2e6;
        }

        .main-navbar {
            background-color: #0099ff;
        }

        .main-navbar .nav-link {
            color: white !important;
        }

        .main-navbar .nav-link.active,
        .main-navbar .nav-link:hover {
            background-color: white !important;
            color: #0099ff !important;
            border-radius: 5px;
            padding: 6px 12px;
        }
        .logo-circle {
    height: 70px;
    width: 70px;
    object-fit: cover;
    border-radius: 50%; /* Makes the logo circular */
    border: 1px solid #0099ff; /* Optional: colored border */
}

.top-bar .container {
    align-items: flex-end !important; /* Bottom align */
    padding-left: 0 !important;       /* Remove left padding if needed */
}

.top-bar {
    padding-bottom: -20px;                /* Tight fit with bottom */
}
html, body {
    height: 100vh;
    width: 100vw;
    overflow-x: hidden;   /* Disable horizontal scroll */
    overflow-y: auto;     /* Enable vertical scroll */
    margin: 0;
    padding: 0;
    white-space: normal;
}

section {
    display: block;
    width: 100%;
    height: auto;         /* Allow section height to adjust based on content */
    padding: 20px;
    box-sizing: border-box;
}
 .testimonial-card {
            background: white;
            border: 1px solid #eee;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
            text-align: center;
            direction: rtl;
            height: 100%;
        }
        .testimonial-card img {
            border-radius: 10px;
            width: 100%;
            height: 300px;
            object-fit: cover;
        }
        .testimonial-card h4 {
            font-weight: bold;
            margin-top: 15px;
            font-size: 24px;
        }
        .stars {
            color: #000;
            font-size: 26px;
            margin-bottom: 10px;
        }
        .testimonial-card p {
            font-size: 18px;
            line-height: 1.8;
        }
        

    .lang-select {
        position: relative;
    }
    
    /* Hide all Google branding */
    .goog-te-gadget {
        color: transparent !important;
    }
    
    .goog-te-gadget-icon {
        display: none !important;
    }
    
    .goog-te-gadget-simple {
        background-color: transparent !important;
        border: none !important;
        padding: 0 !important;
    }
    
    /* Style the select box */
    .goog-te-combo {
        padding: 8px 12px;
        border: 1px solid #ccc;
        border-radius: 4px;
        background: #f8f8f8;
        color:rgb(200, 36, 36);
        font-size: 14px;
    }

    </style>
</head>
<body>

    <!-- 🟦 Top Bar -->
   <div class="top-bar py-2">
    <div class="container d-flex justify-content-between align-items-center" style="direction: ltr;">
        
        <!-- Left: Logo -->
   <div class="logo-container" style="margin-bottom: -6px; margin-left:-60px; padding-left: 0;">
            <a href="<?php echo e(url('/')); ?>" class="d-block">
                <img src="images/scrap-buyers-riyadh-Logo-Final-1.png"
                     alt="مشتري خردة الرياض"
                     class="img-fluid"
                     style="max-width: 120px;">
            </a>
        </div>
        <!-- Right: Contact Info + Language Selector -->
        <div class="d-flex align-items-center gap-3">
            <div class="text-end">
                <div class="fw-bold">  <a href="tel:+966543282605" class="text-decoration-none text-dark">
            +966 54 328 2605
        </a></div>
                <div><a href="mailto:info@scrapbuyersriyadh.com">info@scrapbuyersriyadh.com</a></div>
            </div>
            <div id="google_translate_element" class="lang-select"></div>
        </div>
    </div>
</div>
    <!-- 🟦 Main Navbar -->
    <nav class="navbar navbar-expand-lg main-navbar" >
        <div class="container justify-content-end">
            <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-end" id="mainNav">
                <ul class="navbar-nav mb-2 mb-lg-0 d-flex flex-row-reverse gap-3">
                   <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">
            الصفحة الرئيسية
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('services') ? 'active' : ''); ?>" href="<?php echo e(route('services')); ?>">
            خدمات
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('about') ? 'active' : ''); ?>" href="<?php echo e(route('about')); ?>">
            معلومات عنا
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>" href="<?php echo e(route('contact')); ?>">
            اتصل بنا
        </a>
    </li>
                   <!-- <li class="nav-item ms-auto">
    <a class="nav-link fw-bold" href="#" style="background-color: white; color:rgb(140, 188, 220); border-radius: 5px; padding: 6px 12px;">
        المواعيد
    </a>
</li> -->
                </ul>
            </div>
        </div>
    </nav>
    <br><br>

    <br><br><br>

    <!-- 🟦 Main Content -->
  <main id="MainContent" class="content-for-layout focus-none" role="main" tabindex="-1">

    <!-- ✅ Section 1: Desktop Version -->
    <section class="py-5 text-white d-none d-lg-block"
             style="background-color: rgba(27, 26, 26, 0.6); min-height: 100vh; display: flex; align-items: center;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-12 text-center">

                    <h2 class="mb-3">بيع جميع أنواع الخردة المعدنية</h2>
                    <br><br>
                    <p class="mb-4">

                        نقوم بشراء جميع أنواع الخردة المعدنية: أسلاك الحديد، الأسلاك النحاسية، الألومنيوم، البطاريات المستخدمة، خردة تكييف الهواء.<br>
                        نحن نشتري جميع أنواع الخردة المعدنية في المملكة العربية السعودية - الرياض، والمعادن  والمواد غير الحديدية.<br>
                        اتصل بنا للحصول على عرض أسعار <br>مخصص وخالي من المتاعب لمشروعك في السعودية - الرياض.
                    </p>
                    <br>
                    <div class="d-flex justify-content-center gap-3 flex-wrap">
                        <a href="https://wa.me/+966543282605" class="btn btn-success" target="_blank">WhatsApp</a>
                        <a href="tel:+966543282605" class="btn btn-primary">Call Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ✅ Section 2: Mobile Only Version -->
    <section class="py-5 text-white d-lg-none"
             style="background-color: rgba(0, 0, 0, 0.37); min-height: 100vh; display: flex; align-items: center;">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h3 class="mb-3">بيع جميع أنواع الخردة المعدنية</h3>
                    <p>
                        نقوم بشراء جميع أنواع الخردة المعدنية: أسلاك الحديد، الأسلاك النحاسية، الألومنيوم، البطاريات المستخدمة، خردة تكييف الهواء.<br>
                        نحن نشتري جميع أنواع الخردة المعدنية في المملكة العربية السعودية - الرياض، والمعادن والمواد غير الحديدية.<br>
                        اتصل بنا للحصول على عرض أسعار مخصص وخالي من المتاعب لمشروعك في السعودية - الرياض.
                    </p>
                    <div class="d-flex justify-content-center gap-3 mt-3 flex-wrap">
                        <a href="https://wa.me/+966543282605" class="btn btn-success" target="_blank">WhatsApp</a>
                        <a href="tel:+966543282605" class="btn btn-primary">Call Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

</main>
<br>

<section class="py-5 bg-white text-black">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-md-10 col-lg-8">
                <h3 class="mb-4 text-center">شراء سكراب حديد الرياض</h3>
                <div class="form-check mb-3">
                    <!-- <input class="form-check-input" type="checkbox" id="scrapCheck"> -->
                    <label class="form-check-label" for="scrapCheck">
                        نحن متخصصون في شراء سكراب حديد الرياض بأسعار تنافسية وجودة عالية. فريقنا ملتزم بتقديم أفضل الخدمات لعملائنا بسرعة واحترافية كبيرة.
                    </label>
                </div>
            </div>
        </div>
    </div>
</section>
<br>
<section class="py-5 bg-light">
    <div class="container">
        <div class="row">
            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/hurda-demirr-1024x608.jpg" class="card-img-top" alt="نشتري السكراب">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">نشتري السكراب</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/IMG_20240830_160515698-1536x1157.webp" class="card-img-top" alt="خردة الألومنيوم">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">خردة الألومنيوم</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/XXL_height_1.webp?" class="card-img-top" alt="شراء السكراب حديد خردة بالرياض">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">شراء السكراب حديد خردة بالرياض</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/خردة جنوط الألومنيوم.jpg" class="card-img-top" alt="خردة جنوط الألومنيوم">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">خردة جنوط الألومنيوم</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/5.webp" class="card-img-top" alt="سكراب ألمنيوم">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">سكراب ألمنيوم</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/6.webp" class="card-img-top" alt="سكراب ستيل">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">قطعة من الكمبيوتر</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/7.jpg" class="card-img-top" alt="نحاس قديم">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">خردة المحركات الكهربائية للمضخات</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/8.jpg" class="card-img-top" alt="سكراب حديد">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">خردة المواد الحديدية</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/9.jpg" class="card-img-top" alt="خردة متنوعة">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">قصاصة من لوح الكسوة
</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/10.jpg" class="card-img-top" alt="خردة معادن">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">خردة بطارية الرصاص</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/11.jpg" class="card-img-top" alt="خردة سيارات">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">قصاصة من المبرد</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/12.jpg" class="card-img-top" alt="سكراب نحاس أصفر">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">سكراب الرياض شراء</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/13.jpg" class="card-img-top" alt="سكراب متنوع">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">شراء خردة المعادن في الرياض
</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/14.jpg" class="card-img-top" alt="نشتري جميع الخردة">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">خردة النحاس</h5>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 mb-4">
                <div class="card text-center h-100">
                    <img src="images/15.jpg" class="card-img-top" alt="إعادة تدوير الخردة">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">خردة المواد الكهربائية</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<br>
<section class="py-5 bg-white text-black">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-md-10 col-lg-8">
                <h3 class="mb-4 text-center">ماذا يقول عملاؤنا</h3>
                <div class="form-check mb-3">
                    <!-- <input class="form-check-input" type="checkbox" id="scrapCheck"> -->
                    <label class="form-check-label" for="scrapCheck">
                       كانت تجربتنا رائعة - خدمة ودودة، استجابة سريعة، وقيمة ممتازة. نوصي بها بشدة لكل من يبحث عن الموثوقية والاحترافية وخدمة عملاء متميزة.
                    </label>
                </div>
            </div>
        </div>
    </div>
</section>
<br>
<div class="container my-5">
    <div class="row g-4 justify-content-center">
        <!-- Testimonial 1 -->
        <div class="col-md-4">
            <div class="testimonial-card">
                <img src="images/Asla.jpg" alt="أسلم علي">
                <h4>أسلم علي</h4>
                <div class="stars">★★★</div>
                <p>تواصلتُ معهم لأول مرة، وانبهرتُ بأمانتهم وكفاءتهم. تم إنجاز كل شيء في الوقت المحدد. خدمة ممتازة.</p>
            </div>
        </div>
        <!-- Testimonial 2 -->
        <div class="col-md-4">
            <div class="testimonial-card">
                <img src="images/khalil.jpg" alt="خليل وليد">
                <h4>خليل وليد</h4>
                <div class="stars">★★★</div>
                <p>كان فريقهم متعاونًا للغاية. جمعوا جميع الخردة القديمة بسعر مناسب، بل ونظفوها بعد ذلك. لقد أعجبني حقًا.</p>
            </div>
        </div>
        <!-- Testimonial 3 -->
        <div class="col-md-4">
            <div class="testimonial-card">
                <img src="images/jameel.jpg" alt="جميل كمران">
                <h4>جميل كمران</h4>
                <div class="stars">★★★</div>
                <p>كنت أعتقد أن التعامل مع الخردة أمرٌ مُرهق، لكنهم تعاملوا مع كل شيء %١٠٠ بسلاسة. أنصح بهم بشدة.</p>
            </div>
        </div>
    </div>
</div>
<br>
<!-- Google Map Section -->
<section class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <iframe
                width="100%"
                height="450"
                style="border:0;"
                loading="lazy"
                allowfullscreen
                title="Google Map"
                src="https://maps.google.com/maps?z=14&t=m&q=Riyadh&ie=UTF8&output=embed"
            ></iframe>
        </div>
    </div>
</section>

<br>


<br><br>
<!-- Contact Section -->
<section class="contact-section bg-primary text-white py-4">
    <div class="container">
        <div class="row align-items-center">
            <!-- Email -->
           <div class="col-md-4 text-center text-md-start">
    <div class="d-flex align-items-center justify-content-center h-100">
        <i class="fas fa-envelope fa-2x mb-2"></i>
    </div>
    <p><a href="mailto:info@scrapbuyersriyadh.com" class="text-white">info@scrapbuyersriyadh.com</a></p>
</div>

   
    <div class="col-md-4 d-flex flex-column align-items-center" dir="ltr">
    <i class="fas fa-phone fa-2x mb-2"></i>
    <div class="fw-bold">
        <a href="tel:+966543282605" class="text-decoration-none text-white">
            +966 54 328 2605
        </a>
    </div>
</div>
            <!-- Location -->
            <div class="col-md-4 text-center text-md-end">
                <i class="fas fa-map-marker-alt fa-2x mb-2"></i>
                <p>جدة، الرياض</p>
            </div>
        </div>
    </div>
</section>

<br><br>

<footer id="Banner-footer" class="index-footer footer bg-dark text-white py-5" dir="ltr">
    <div class="container">
        <div class="row">
            <!-- Block 1: Logo & Description -->
            <div class="col-md-4 mb-4">
                <a href="<?php echo e(url('/')); ?>" class="footer_link d-block mb-3">
                    <img src="images/scrap-buyers-riyadh-Logo-Final-1.png"
                         alt="مشتري خردة الرياض"
                         class="img-fluid" style="max-width: 200px;">
                </a>
                <p class="mt-3 text-white">
                    نقوم بشراء جميع أنواع الخردة المعدنية أسلاك الحديد الأسلاك النحاسية الألومنيوم البطاريات المستخدمة خردة تكييف الهواء نحن نشتري جميع أنواع الخردة المعدنية في المملكة العربية السعودية الرياض والمعادن والمواد غير الحديدية.
                </p>

                <!-- Social Icons -->
                <div class="social_icons mt-4">
                    <p>Follow Us:</p>
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item me-2">
                            <a href="#" class="text-white text-decoration-none">
                                <i class="fab fa-twitter fs-5"></i>
                            </a>
                        </li>
                        <li class="list-inline-item me-2">
                            <a href="#" class="text-white text-decoration-none">
                                <i class="fab fa-facebook fs-5"></i>
                            </a>
                        </li>
                        <li class="list-inline-item me-2">
                            <a href="#" class="text-white text-decoration-none">
                                <i class="fab fa-instagram fs-5"></i>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="#" class="text-white text-decoration-none">
                                <i class="fab fa-youtube fs-5"></i>
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- WhatsApp Icon (Removed) -->
                <!--
                <div class="mt-4">
                    <a href="tel:+966543282605" class="d-inline-block">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50" fill="none">
                            <circle cx="25" cy="25" r="25" fill="#25D366"/>
                            <path d="M25 2.5C11.293 2.5 2.5 11.293 2.5 25C2.5 38.707 11.293 47.5 25 47.5C38.707 47.5 47.5 38.707 47.5 25C47.5 11.293 38.707 2.5 25 2.5Z" fill="#fff"/>
                            <path d="M25 4.1667C13.75 4.1667 4.1667 13.75 4.1667 25C4.1667 36.25 13.75 45.8333 25 45.8333C36.25 45.8333 45.8333 36.25 45.8333 25C45.8333 13.75 36.25 4.1667 25 4.1667Z" fill="#fff"/>
                            <path d="M25 8.33333C18.8333 8.33333 13.3333 13.8333 13.3333 20C13.3333 26.1667 18.8333 31.6667 25 31.6667C31.1667 31.6667 36.6667 26.1667 36.6667 20C36.6667 13.8333 31.1667 8.33333 25 8.33333Z" fill="#fff"/>
                        </svg>
                    </a>
                </div>
                -->

            </div>

            <!-- Block 2: Services Menu -->
            <div class="col-md-4 mb-4">
                <ul class="footer_menu list-unstyled">
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('services')); ?>" class="text-white">خدمات</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(url('/')); ?>" class="text-white">شراء سكراب حديد</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(url('/')); ?>" class="text-white">الرياض</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(url('/')); ?>" class="text-white">نشتري السكراب</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(url('/')); ?>" class="text-white">شراء السكراب حديد</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(url('/')); ?>" class="text-white">خردة بالرياض</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(url('/')); ?>" class="text-white">شراء حديد سكراب</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(url('/')); ?>" class="text-white">الرياض</a></li>
                </ul>
            </div>

            <!-- Block 3: Main Links -->
            <div class="col-md-4 mb-4">
                <ul class="footer_menu list-unstyled">
                    <li><span class="text-primary">•</span> <a href="<?php echo e(url('/')); ?>" class="text-white">الصفحة الرئيسية</a></li>
                    <li><span class="text-primary">•</span> <a href="" class="text-white">اتصل بنا</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('about')); ?>" class="text-white">معلومات عنا</a></li>
                    <li><span class="text-primary">•</span> <a href="<?php echo e(route('services')); ?>" class="text-white">خدمات</a></li>
                </ul>

                <!-- Images Grid -->
                <div class="row g-2 mt-4">
                   <?php $__currentLoopData = range(1, 6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img src="<?php echo e(asset('images/images_' . $i . '.jpg')); ?>" alt="Image <?php echo e($i); ?>" class="img-thumbnail m-2" style="width: 150px;">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
</div>
</div>
</div>
  </footer>

        <!-- Bottom Footer -->
       <div class=" bg-primary ">
        <!-- Left Column: Copyright and Social Icons -->
       <div class="row justify-content-center">
  <div class="col-md-6 text-center">
    <small class="copyright__content text-white">
      &copy; Copyright © 2025 Design by Innovative Technologies
    </small>
  </div>
</div>
</div>

<!-- Fixed Call/WhatsApp Buttons -->
<div class="fixed-bottom d-flex justify-content-between p-3" style="z-index: 1000;" dir="ltr">
    <!-- Call Button - Left Side -->
    <a href="tel:+966543282605" class="btn btn-success rounded-circle shadow-lg" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
        <i class="fas fa-phone-alt fa-lg text-white"></i>
    </a>
    
    <!-- WhatsApp Button - Right Side -->
    <a href="https://wa.me/966543282605" class="btn btn-success rounded-circle shadow-lg" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
        <i class="fab fa-whatsapp fa-lg text-white"></i>
    </a>
</div>


    <!-- ✅ Google Translate Script -->
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ar',
                layout: google.translate.TranslateElement.InlineLayout.SIMPLE
            }, 'google_translate_element');
        }
       
    </script>
    <script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    <!-- ✅ Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php /**PATH E:\scrapbuyersriyadh\scrapbuyersriyadh\resources\views/index.blade.php ENDPATH**/ ?>