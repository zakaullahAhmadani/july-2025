<?php
// Enable error reporting for debugging (Remove on production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// DB config
$host = "localhost";
$user = "root";
$password = "";
$dbname = "dubaifixmyappliances";

// Connect to database
$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Sanitize input
function sanitizeInput($data) {
    global $conn;
    return $conn->real_escape_string(trim($data));
}

// Assign sanitized variables
$firstName = sanitizeInput($_POST['firstName'] ?? '');
$lastName  = sanitizeInput($_POST['lastName'] ?? '');
$email     = sanitizeInput($_POST['email'] ?? '');
$phone     = sanitizeInput($_POST['phone'] ?? '');
$comment   = sanitizeInput($_POST['comment'] ?? '');

// Basic validation
if ($firstName && $lastName && $email && $comment) {
    $sql = "INSERT INTO contact_form (first_name, last_name, email, phone, comment) 
            VALUES (?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $firstName, $lastName, $email, $phone, $comment);
    
    if ($stmt->execute()) {
        echo "<span style='color:green;'>Thank you! Your message has been sent successfully.</span>";
    } else {
        echo "<span style='color:red;'>Database Error: " . $stmt->error . "</span>";
    }

    $stmt->close();
} else {
    echo "<span style='color:red;'>Please fill in all required fields.</span>";
}

$conn->close();
?>
