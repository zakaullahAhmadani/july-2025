<?php
$conn = new mysqli("localhost", "root", "", "junkremovalDubi");
if ($conn->connect_error) {
    echo "Database connection failed.";
    exit();
}

$form = $_POST['form_fields'] ?? [];

$name = trim($form["name"] ?? '');
$email = trim($form["email"] ?? '');
$subject = trim($form["field_55aee6c"] ?? '');
$message = trim($form["message"] ?? '');

if (empty($name) || empty($email) || empty($subject) || empty($message)) {
    echo "All fields are required.";
    exit();
}

$sql = "INSERT INTO contact_form_entries (name, email, subject, message) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $name, $email, $subject, $message);

if ($stmt->execute()) {
    echo "Success! Your message has been submitted.";
} else {
    echo "Failed to send your message. Please try again.";
}

$stmt->close();
$conn->close();
?>
